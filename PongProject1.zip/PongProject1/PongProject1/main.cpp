
//---------------------------------------------------------
// File : main.cpp
// Class: COP 3003, Spring 2023
// Devel: Diego Sanchez
// Desc : A game pong
//---------------------------------------------------------


//Headers
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <cmath>
#include <ctime>
#include <cstdlib>




int main()
{
    std::srand(static_cast<unsigned int>(std::time(NULL)));

    // Define some constants
    const float pi = 3.14159f;
    const int gameWidth = 1000;
    const int gameHeight = 800;
    float ballRadius = 8.f;
    sf::Vector2f paddleSize(20, 80);


    int enemyScore = 0;
    int homeScore = 0;


    // Create the window of the application
    sf::RenderWindow window(sf::VideoMode(gameWidth, gameHeight, 32), "Pong The Game",
        sf::Style::Titlebar | sf::Style::Close);
    window.setVerticalSyncEnabled(true);


    // Creating the user's paddle and the properties of the paddle
    sf::RectangleShape userPaddle;
    userPaddle.setSize(paddleSize - sf::Vector2f(4, 5));
    userPaddle.setOutlineColor(sf::Color(0, 0, 0));
    userPaddle.setFillColor(sf::Color(35, 200, 50));
    userPaddle.setOutlineThickness(1);
    userPaddle.setOrigin(paddleSize / 3.f);

    // Creating the opponet's paddle and the properties of the paddle
    sf::RectangleShape enemyPaddle;
    enemyPaddle.setSize(paddleSize - sf::Vector2f(4, 5));
    enemyPaddle.setOutlineColor(sf::Color(0,0,0));
    enemyPaddle.setFillColor(sf::Color(200, 150, 40));
    enemyPaddle.setOutlineThickness(1);
    enemyPaddle.setOrigin(paddleSize / 3.f);

    // Creating the ball and the properties of ball
    sf::CircleShape ball;
    ball.setRadius(ballRadius - 3);
    ball.setOutlineThickness(1);
    ball.setOutlineColor(sf::Color(0, 0, 0));
    ball.setFillColor(sf::Color(255, 255, 255));
    ball.setOrigin(ballRadius / 3, ballRadius / 3);

    // Load the font
    sf::Font font;
    if (!font.loadFromFile("resources/sansation.ttf"))
        return EXIT_FAILURE;

    // Creating the pause message
    sf::Text pauseMessage;
    pauseMessage.setFont(font);
    pauseMessage.setCharacterSize(40);
    pauseMessage.setPosition(170.f, 150.f);
    pauseMessage.setFillColor(sf::Color(255, 255, 255));
    pauseMessage.setString("Press the spacebar to continue ");

    // Define the paddles properties
    sf::Clock AITimer;
    const sf::Time AITime = sf::seconds(0.1f);
    const float paddleSpeed = 550.f;
    float enemyPaddleSpeed = 0.f;
    float ballSpeed = 550;
    float ballAngle = 0.f;

    sf::Clock clock;
    bool isPlaying = false;
    while (window.isOpen())
    {
        // status/events of gamestate
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Window closed or escape key pressed
            if ((event.type == sf::Event::Closed) ||
                ((event.type == sf::Event::KeyPressed) && (event.key.code == sf::Keyboard::Escape)))
            {
                window.close();
                break;
            }

            // Space key pressed: play
            if ((event.type == sf::Event::KeyPressed) && (event.key.code == sf::Keyboard::Space))
            {
                if (!isPlaying)
                {
                    // start the game
                    isPlaying = true;
                    clock.restart();

                    // Reset the position of the paddles and ball
                    userPaddle.setPosition(10 + paddleSize.x / 3, gameHeight / 3);
                    enemyPaddle.setPosition(gameWidth - 10 - paddleSize.x / 3, gameHeight / 3);
                    ball.setPosition(gameWidth / 3, gameHeight / 3);

                    // Reset the ball angle
                    do
                    {
                        // Make sure the ball initial angle is not too much vertical
                        ballAngle = (std::rand() % 360) * 2 * pi / 360;
                    } while (std::abs(std::cos(ballAngle)) < 0.7f);
                }
            }
        }

        if (isPlaying)
        {
            float deltaTime = clock.restart().asSeconds();

            // Move the player's paddle
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) &&
                (userPaddle.getPosition().y - paddleSize.y / 3 > 5.f))
            {
                userPaddle.move(0.f, -paddleSpeed * deltaTime);
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) &&
                (userPaddle.getPosition().y + paddleSize.y / 3 < gameHeight - 5.f))
            {
                userPaddle.move(0.f, paddleSpeed * deltaTime);
            }

            // Move the opponet's paddle
            if (((enemyPaddleSpeed < 0.f) && (enemyPaddle.getPosition().y - paddleSize.y / 3 > 5.f)) ||
                ((enemyPaddleSpeed > 0.f) && (enemyPaddle.getPosition().y + paddleSize.y / 3 < gameHeight - 5.f)))
            {
                enemyPaddle.move(0.f, enemyPaddleSpeed * deltaTime);
            }

            // the opponet's paddle moves relation to the ball
            if (AITimer.getElapsedTime() > AITime)
            {
                AITimer.restart();
                if (ball.getPosition().y + ballRadius > enemyPaddle.getPosition().y + paddleSize.y / 3)
                    enemyPaddleSpeed = paddleSpeed;
                else if (ball.getPosition().y - ballRadius < enemyPaddle.getPosition().y - paddleSize.y / 3)
                    enemyPaddleSpeed = -paddleSpeed;
                else
                    enemyPaddleSpeed = 0.f;
            }

            // Move the ball
            float factor = ballSpeed * deltaTime;
            ball.move(std::cos(ballAngle) * factor, std::sin(ballAngle) * factor);

            // Checks if paddle misses ball and adds to score
            if (ball.getPosition().x - ballRadius < 0.f)
            {
                isPlaying = false;
                pauseMessage.setString("Enemy + 1!\nPress space contine");
                enemyScore++;
            }
            if (ball.getPosition().x + ballRadius > gameWidth)
            {
                isPlaying = false;
                pauseMessage.setString("Home + 1!\nPress space contine");
                homeScore++;

            }
            if (ball.getPosition().y - ballRadius < 0.f)
            {
                ballAngle = -ballAngle;
                ball.setPosition(ball.getPosition().x, ballRadius + 0.1f);
            }
            if (ball.getPosition().y + ballRadius > gameHeight)
            {

                ballAngle = -ballAngle;
                ball.setPosition(ball.getPosition().x, gameHeight - ballRadius - 0.1f);
            }

            // Check the physics between the ball and the paddles

            // userPaddle physics + ball speeds up
            if (ball.getPosition().x - ballRadius < userPaddle.getPosition().x + paddleSize.x / 2 &&
                ball.getPosition().x - ballRadius > userPaddle.getPosition().x &&
                ball.getPosition().y + ballRadius >= userPaddle.getPosition().y - paddleSize.y / 2 &&
                ball.getPosition().y - ballRadius <= userPaddle.getPosition().y + paddleSize.y / 2)
            {
                //ballSpeed = ballSpeed +200;
                if (ball.getPosition().y > userPaddle.getPosition().y)
                    ballAngle = pi - ballAngle + (std::rand() % 20) * pi / 180;
                else
                    ballAngle = pi - ballAngle - (std::rand() % 20) * pi / 180;
                ball.setPosition(userPaddle.getPosition().x + ballRadius + paddleSize.x / 2 + 0.1f, ball.getPosition().y);
            }

            // Enemy Paddle physics + ball speeds up
            if (ball.getPosition().x + ballRadius > enemyPaddle.getPosition().x - paddleSize.x / 2 &&
                ball.getPosition().x + ballRadius < enemyPaddle.getPosition().x &&
                ball.getPosition().y + ballRadius >= enemyPaddle.getPosition().y - paddleSize.y / 2 &&
                ball.getPosition().y - ballRadius <= enemyPaddle.getPosition().y + paddleSize.y / 2)
            {
                //ballSpeed = ballSpeed + 200;
                if (ball.getPosition().y > enemyPaddle.getPosition().y)
                    ballAngle = pi - ballAngle + (std::rand() % 20) * pi / 180;
                else
                    ballAngle = pi - ballAngle - (std::rand() % 20) * pi / 180;

                ball.setPosition(enemyPaddle.getPosition().x - ballRadius - paddleSize.x / 2 - 0.1f, ball.getPosition().y);
            }
        }

        // Clear the window
        window.clear(sf::Color(9, 28, 57));

        if (isPlaying)
        {
            // Display home score
            sf::Text Home_Score;
            Home_Score.setFont(font);
            Home_Score.setCharacterSize(40);
            Home_Score.setPosition(150.f, 100.f);
            Home_Score.setFillColor(sf::Color(255, 255, 255));
            Home_Score.setString("Home: ");
            window.draw(Home_Score);

            // Display enemy score
            sf::Text Enemy_Score;
            Enemy_Score.setFont(font);
            Enemy_Score.setCharacterSize(40);
            Enemy_Score.setPosition(700.f, 100.f);
            Enemy_Score.setFillColor(sf::Color(255, 255, 255));
            Enemy_Score.setString("Enemy: ");
            window.draw(Enemy_Score);

            // Draw the paddles and the ball
            window.draw(userPaddle);
            window.draw(enemyPaddle);
            window.draw(ball);
        }
        else
        {
            // Draw the pause message
            window.draw(pauseMessage);
        }

        // Display things on screen
        window.display();
    }

    return EXIT_SUCCESS;
}
//// Not able to get an excecutable to work
